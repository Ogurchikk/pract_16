﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace task_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ввод массива
            Console.WriteLine("Введите элементы массива через пробел (включая символ '/'):");
            string input = Console.ReadLine()?.Trim();

            if (string.IsNullOrEmpty(input))
            {
                Console.WriteLine("Ошибка: ввод пуст.");
                return;
            }

            string[] inputArray = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // А) Подсчет цифр
            List<char> digits = new List<char>();
            foreach (string item in inputArray)
            {
                foreach (char c in item)
                {
                    if (char.IsDigit(c))
                    {
                        digits.Add(c);
                    }
                }
            }
            Console.WriteLine("\n[A] Найденные цифры: " + string.Join(", ", digits));
            Console.WriteLine("Количество цифр: " + digits.Count);

            // Б) Элементы до первого "/"
            List<string> beforeSlash = new List<string>();
            foreach (string item in inputArray)
            {
                if (item.Contains("/"))
                {
                    break;
                }
                beforeSlash.Add(item);
            }
            Console.WriteLine("\n[Б] Элементы до символа '/': " + string.Join(", ", beforeSlash));

            // В) Элементы после "/" с инверсией регистра
            int slashIndex = -1;
            for (int i = 0; i < inputArray.Length; i++)
            {
                if (inputArray[i].Contains("/"))
                {
                    slashIndex = i;
                    break;
                }
            }

            if (slashIndex == -1)
            {
                Console.WriteLine("\n[В] Символ '/' не найден.");
                return;
            }

            List<string> processedElements = new List<string>();
            for (int i = slashIndex + 1; i < inputArray.Length; i++)
            {
                char[] chars = inputArray[i].ToCharArray();
                for (int j = 0; j < chars.Length; j++)
                {
                    if (char.IsLetter(chars[j]))
                    {
                        chars[j] = char.IsUpper(chars[j]) ? char.ToLower(chars[j]) : char.ToUpper(chars[j]);
                    }
                }
                processedElements.Add(new string(chars));
            }

            Console.WriteLine("\n[В] Элементы после '/' с измененным регистром: " + string.Join(", ", processedElements));

            // Запись в файл
            if (processedElements.Count > 0)
            {
                try
                {
                    File.WriteAllLines("output.txt", processedElements);
                    Console.WriteLine("Результат записан в файл 'output.txt'");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка записи: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine("Нет элементов для записи в файл.");
            }
        }
    }
}
