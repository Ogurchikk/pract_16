﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace task_1
{
    public partial class Form1 : Form
    {
        private string _loadedText = "";

        public MainForm()
        {
            InitializeComponent();
            // Привязка обработчиков событий
            btnLoadFile.Click += BtnLoadFile_Click;
            btnSearch.Click += BtnSearch_Click;
        }

        // Обработчик загрузки файла
        private void BtnLoadFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Чтение файла и отображение содержимого
                        _loadedText = File.ReadAllText(openFileDialog.FileName);
                        txtFileContent.Text = _loadedText;
                        lblResult.Text = "Файл успешно загружен!";
                    }
                    catch (Exception ex)
                    {
                        lblResult.Text = $"Ошибка: {ex.Message}";
                    }
                }
            }
        }

        // Обработчик поиска слова
        private void BtnSearch_Click(object sender, EventArgs e)
        {
            string searchWord = txtSearchWord.Text.Trim();

            // Проверка на ошибки
            if (string.IsNullOrEmpty(_loadedText))
            {
                lblResult.Text = "Ошибка: файл не загружен!";
                return;
            }
            if (string.IsNullOrEmpty(searchWord))
            {
                lblResult.Text = "Ошибка: введите слово для поиска!";
                return;
            }

            // Разделение текста на слова
            char[] separators = { ' ', ',', '.', '!', '?', ';', ':', '-', '\n', '\r', '\t' };
            string[] words = _loadedText.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            // Подсчёт вхождений через LINQ
            var query = from word in words
                        where word.Equals(searchWord, StringComparison.OrdinalIgnoreCase)
                        select word;

            int count = query.Count();

            // Вывод результата
            lblResult.Text = $"Найдено вхождений: {count} (слово: \"{searchWord}\")";
        }
    }
}
