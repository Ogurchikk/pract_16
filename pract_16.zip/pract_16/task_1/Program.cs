﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace task_1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Чтение текста из файла
            string filePath = "text.txt";
            string text;
            try
            {
                text = File.ReadAllText(filePath);

                // Вывод содержимого файла
                Console.WriteLine("Содержимое файла:");
                Console.WriteLine("--------------------------------------------------------------------------------------------");
                Console.WriteLine(text);
                Console.WriteLine("--------------------------------------------------------------------------------------------\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
                return;
            }

            // Ввод слова для поиска
            Console.Write("Введите слово для поиска: ");
            string searchWord = Console.ReadLine().Trim();

            if (string.IsNullOrEmpty(searchWord))
            {
                Console.WriteLine("Слово для поиска не введено.");
                return;
            }

            // Подсчет вхождений (без учета регистра и с учетом границ слов)
            string pattern = $@"\b{Regex.Escape(searchWord)}\b";
            int count = Regex.Matches(text, pattern, RegexOptions.IgnoreCase).Count;

            // Вывод результата
            Console.WriteLine($"\nБыли найдены {count} вхождений(ие) поискового запроса \"{searchWord}\"");
        }
    }
}
